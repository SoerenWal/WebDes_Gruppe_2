const navToggle = document.querySelector('.nav-toggle');
const mainNav = document.querySelector('.main-nav');

if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
        const isOpen = mainNav.classList.toggle('is-open');
        navToggle.setAttribute('aria-expanded', String(isOpen));
        navToggle.setAttribute('aria-label', isOpen ? 'Navigation schließen' : 'Navigation öffnen');
    });

    mainNav.addEventListener('click', (event) => {
        if (event.target.tagName === 'A') {
            mainNav.classList.remove('is-open');
            navToggle.setAttribute('aria-expanded', 'false');
            navToggle.setAttribute('aria-label', 'Navigation öffnen');
        }
    });
}

const revealElements = document.querySelectorAll('.reveal');

if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                revealObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12 });

    revealElements.forEach((element) => revealObserver.observe(element));
} else {
    revealElements.forEach((element) => element.classList.add('is-visible'));
}

const yearElement = document.getElementById('currentYear');
if (yearElement) {
    yearElement.textContent = String(new Date().getFullYear());
}

const canvas = document.getElementById('routeCanvas');
const routeItems = document.querySelectorAll('.timeline__item');
let activeStep = 0;

const steps = [
    { label: 'Römer', x: 95, y: 285, icon: '🏛️' },
    { label: 'Eis', x: 230, y: 205, icon: '🍦' },
    { label: 'Main', x: 405, y: 255, icon: '🌊' },
    { label: 'Skyline', x: 600, y: 125, icon: '🌆' }
];

function drawRoute() {
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);

    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, '#fff3df');
    gradient.addColorStop(1, '#dfe9f8');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = 'rgba(23, 32, 51, 0.12)';
    ctx.lineWidth = 1;
    for (let x = 40; x < width; x += 80) {
        ctx.beginPath();
        ctx.moveTo(x, 36);
        ctx.lineTo(x, height - 36);
        ctx.stroke();
    }
    for (let y = 40; y < height; y += 70) {
        ctx.beginPath();
        ctx.moveTo(36, y);
        ctx.lineTo(width - 36, y);
        ctx.stroke();
    }

    ctx.strokeStyle = 'rgba(73, 111, 157, 0.32)';
    ctx.lineWidth = 28;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(40, 322);
    ctx.bezierCurveTo(180, 288, 315, 335, 470, 295);
    ctx.bezierCurveTo(540, 276, 606, 240, 684, 252);
    ctx.stroke();

    ctx.strokeStyle = '#e4664f';
    ctx.lineWidth = 5;
    ctx.setLineDash([12, 12]);
    ctx.beginPath();
    ctx.moveTo(steps[0].x, steps[0].y);
    for (let i = 1; i < steps.length; i += 1) {
        const prev = steps[i - 1];
        const current = steps[i];
        const midX = (prev.x + current.x) / 2;
        ctx.quadraticCurveTo(midX, prev.y - 80, current.x, current.y);
    }
    ctx.stroke();
    ctx.setLineDash([]);

    steps.forEach((step, index) => {
        const selected = index === activeStep;
        ctx.beginPath();
        ctx.fillStyle = selected ? '#e4664f' : '#172033';
        ctx.arc(step.x, step.y, selected ? 24 : 18, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.font = selected ? '24px Arial' : '18px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(step.icon, step.x, step.y + 1);

        ctx.fillStyle = selected ? '#e4664f' : '#172033';
        ctx.font = 'bold 18px Arial';
        ctx.textBaseline = 'top';
        ctx.fillText(step.label, step.x, step.y + 34);
    });

    ctx.fillStyle = '#172033';
    ctx.font = 'bold 24px Arial';
    ctx.textAlign = 'left';
    ctx.fillText('Date-Route Frankfurt', 42, 54);

    ctx.font = '16px Arial';
    ctx.fillStyle = '#617083';
    ctx.fillText('Vom Römer über den Main zum Skylineblick', 42, 82);
}

function setActiveStep(stepIndex) {
    activeStep = stepIndex;
    routeItems.forEach((item, index) => {
        item.classList.toggle('is-active', index === activeStep);
    });
    drawRoute();
}

routeItems.forEach((item, index) => {
    item.addEventListener('click', () => setActiveStep(index));
    item.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            setActiveStep(index);
        }
    });
});

setActiveStep(0);
