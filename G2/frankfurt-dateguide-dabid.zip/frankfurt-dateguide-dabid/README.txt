Frankfurt DateGuide - Website-Teil fuer Webdesign & Standards

Start:
- index.html im Browser oeffnen.

Enthalten:
- Semantisches HTML5 mit Header, Navigation, Main, Sections und Footer
- Responsive CSS mit Media Queries
- Hero-Video aus dem bereitgestellten Videomaterial
- Audio-Element mit extrahierter Audiospur
- Canvas-Element mit interaktiver Mini-Route
- Inline-SVG als Skyline-Grafik
- PDF-Download mit Kurzroute
- Alt-Texte, Fokus-Stile und Reduced-Motion-Unterstuetzung

Hinweis:
In der hochgeladenen ZIP war keine separate Anforderungsdatei enthalten. Die Umsetzung orientiert sich daher an der vorhandenen Beispielseite und den dort sichtbaren Pflichtteilen: Video, Audio, Canvas, SVG und PDF/Download.
